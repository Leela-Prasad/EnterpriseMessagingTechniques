This chapter setup the initial configuration for the next two chapters
on Spring JMS, so there is nothing much to execute as part of this chapter. 
